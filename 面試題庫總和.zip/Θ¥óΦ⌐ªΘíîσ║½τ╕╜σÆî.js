公司一

- 什麼是 XML 和 JSON 有和不同
- 什麼是 MVC，描述各 M、V、C 扮演的角色
- 什麼是 AJAX，為什麼要用它
- 什麼是 Typescript
- 描述 OOP
- 描述 API
- 描述 Html、Css、Js 扮演的角色
- 在白板寫出 Json 格式和 xml 格式
- 在白板寫出一個 Class、包含建構函式和如何 New 一個實體，如何帶參數給 Class 讓預設的實體有某些屬性.....
- 在白板寫出帶有兩個參數的 Function
- 在電腦寫出 FuzzBuzz 函式，一個數可整除3的顯示"Fuzz"和一個數可整除5的顯示"Buzz"，如果一個數可以被3、5同時整除就顯示"FuzzBuss"
- Librairie和Framework不同之處
- 是否自己會做網站攻擊檢查如injonction

公司二
1. 請描述一下 cookies, sessionStorage 和 localStorage 的區別？
2. 如何實現瀏覽器內多個標籤頁之間的通信？
3. css 隱藏元素的幾種方法 （至少寫出三種）
4. css 置中 （包括水平置中和垂直置中）
5. css3 中的 transform 屬性和 transition 屬性？
6. JS apply 和 call 的用法和區別？
7. 針對 jQuery 的優化方法？
8. jQuery.extend 與 jQuery.fn.extend 的區別？
9. 請講述前端跨域問題產生及解決方法？
10. 請輸入以下代碼輸出的是什麼？為什麼？
var a = 1;
function fn(){
  console.log(a);
  var a = 5;
  console.log(a);
  a++;
  var a;
  fn2();
  console.log(a);
  function fn2(){
    console.log(a);
    a = 20;
    b = 100;
  }
}
fn();
console.log(a);
a = 10;
console.log(a);
console.log(b);

公司三
1. inline elements 和 block-level elements 各有哪些？差異為何？
  如何轉換 block-level elements 為 inline elements？
  inline elements 的 padding 和 margin 可設置嗎？
2. 請描述幾種 css 水平置中和垂直置中的方式。
3. 請描述 css3 和 html5 新特性。
4. 請列舉前端性能優化的方法。
5. 請舉例描述 es6 新的特性另請解釋 promise。
6. 請寫出下面 js 的輸出
  6-1
  for(var i=1; i<5; i++){
    setTimeout(function() {
      console.log(i);
    }, i * 1000);
  }
  6-2
  function test() {
    console.log(a);
    console.log(foo());
    var a = 1;
    function foo() {
      return 2;
    }
  }
  test();
  6-3
  var f = true;
  if(f === true) {
    var a =10;
  }
  function fn() {
    var b = 20;
    c = 30
  }
  fn();
  console.log(a, b, c);
  6-4
  var a = [1, 2, 3];
  var b = a;
  a.push(5);
  var obj = { 1: 'a', 2: b};
  console.log(b, obj[0], obj[1], obg.2);
  6-5
  var fullname = 'John Doe';
  var obj = {
    fullname: 'Colin Ihrig',
    prop: {
      fullname: 'Aurelio De Rosa',
      getFullname: function() {
        return this.fullname;
      }
    }
  };
  console.log(obj.prop.getFullname());
  var test = obj.prop.getFullname;
  console.log(test());
  6-6
  請用 JS 寫出能計算婓波那契數列（Fibonacci）第 N 個值的函式。
  (0, 1, 1, 2, 3, 5, 8, 13, 21...)


公司四
1. 為什麼想轉前端
2. 學習的過程中有什麼最挫折？什麼最有成就感？
3. 學到哪些東西？
4. 自我介紹中提問
5. 期望薪資
6. 之前的薪水

公司五
### 請寫出下列程式 console.log 結果：
​

var oneadAry = ['a', 'b', 'c'];
oneadAry.push('b');
console.log(oneadAry);
​
oneadAry.pop();
console.log(oneadAry);
​
oneadAry.shift();
console.log(oneadAry);
​
oneadAry.unshift('d');
console.log(oneadAry);
​
var tempAry = oneadAry.slice(0, 2);
console.log(tempAry);
```
​
- 請用 foreach 列出 oneadAry 所有值。
​
### 請用 prototype 講 `oneadObj` 加入一個 `name` 屬性，並給值為你的英文名字。
​
### 以下程式碼 `console.log` 的結果是：
​

var foo = 'Hello';
(function() {
  var bar = ' World';
  console.log(foo + bar);
})();
console.log(foo + bar);

​
### 試寫出 json 資料格式。
​
### 試寫出 JavaScript 如何接收 jsonp。
​
### `'=='` 和 `'==='` 有什麼不同？
​
### 以下程式改用三元運算式寫法：
​

if (oneadAry.length == 0) {
  console.log('true');
} else {
  console.log('false');
}

​
### 以下程式兩個判斷式各為什麼結果？
​

var onead;
if(onead === undefined) {
  console.log('true');
} else {
  console.log('false');
}
​
if (onead === 'undifined') {
  console.log('true');
} else {
  console.log('false');
}

​
### 給定一個圖片網址，在拿到圖片後將圖片的寬高設定為 640px、360px，寫出三種作法（Promise 是其中一個）。
​

var imgUrl = 'http://someimages.com/i.png';

​
### 請用 Singleton 方式實作出一個 `oneadObj` 物件。
​
### 請用 Factory Design Pattern 方式實作一個 `oneadObj` 物件。

公司六
1. 為什麼要初始化 CSS 樣式？
2. 請問如何使用 JavaScript 選取此 DOM <div class='menu'></div>
3. 請排出 CSS 優先層級：!importent、tag、id、class。
4. 要寫一個支援 RWD 的網頁，主要使用 CSS 哪個語法？
5. 若不用 float 要如何讓 div 並排？

公司七
CSS
1. 請解釋 em、rem 的差別。
2.

div {
  width: 100px;
  padding: 0 10px;
}
div 實際寬度為何？

3.
div {
  width: 100px;
  padding: 0 10px;
  box-sizing: border-box;
}
div 實際寬度為何？

4.
<div class='blue'>
  <p>
    Text
  </p>
</div>

.blue {
  color: blue;
}

.blue p {
  color: red;
}
Text 的顏色為？

5. 向量圖和點陣圖的差異？
6. display: none; 跟 visibility: hidden; 的差別？
7. 水平垂直置中方法？
8. 解釋盒模型（Box Model）
9. 我有一個 img url: http://123.com/123.jpg 如何單純使用 a 標籤做一個可以下載這張圖片的按鈕？
10. 為什麼要初始化 CSS  樣式？


JS
1. const arr = ['a', 'b', 'c']; 如何讓 arr = ['a', 'b'] ？

2.
const paul = { number: 30 };
const tony = paul;

tony.number = 3;
paul.number ？

3.
const paul = { number: 3 };
const tony = { ...paul };

paul.number = 30;
tony.number ？

4.
const a = 'a';
conat b = undefined;

console.log(a + typeof b);
結果為？

5.
for (let i = 0; i < 5; ++i) {
  setTimeout(function() {
    console.log(i + ' ');
  }, 100);
}
log 答案為何？

6. sessionStorage 和 localStorage 區別？

7. 在瀏覽器環境下，執行會印出什麼？
function logThis() {
  console.log(this);
}

var a = { a: 1, logThis };
var b = { a: 2, logThis };

logThis();
a.logThis();
b.logThis.apply(a);

公司八

1. 請問下列程式碼執行結果中，Hello  和 World 分別會顯示什麼顏色？
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>title</title>
    <style>
      .a { color: red; }
      .b { color: blue; }
    </style>
  </head>
  <body>
    <h1 class='a b'>Hello</h1>
    <h1 class='b a'>World</h1>
  </body>
</html>

2. 假定有一段 JavaScript 程式碼：
var obj = { 1: 'hello', 2: 'world' };
請問：
obj.1
obj[0]
obj[1]
內容分別為何？

3. 於 JavaScript 中，若以 Boolean() 檢核，以下哪些為 true，哪些為 false，哪些既不是 true 也不是 false？
(A) 1 === true
(B) Number(‘1px’)
(C) typeof [1, 2, 3] == ‘array’
(D) ‘0’

4. 於 JavaScript 中，下列程式的執行結果為何？
(A) [1, 2, 3].forEach(n => n + 1)
(B) [1, 2, 3].map(n => n + 1)
(C) [1, 2, 3].filter(n => n === 2)
(D) [1, 2, 3].find(n => n === 3)

5. 請問下列 JavaScript 程式執行結果為何？
var abe = '123';
function test() {
  var def = '456';
  alert(abc + '@' + def);
}
test();
alert(abc + '#' + def);

6. 請問下列 JavaScript 程式執行結果為何？
var x = 10;
var obj = {
  x: 20;
  f: function() {
    var test = function() {
      alert(this.x);
    }
    text();
  }
};
obj.f();

7. 簡答題：名詞解釋
(A) SCSS / Sass
(B) Webpack
(C) RWD
(D) RESTful API
(E) Git

8. 有一組 JSON 資料如下，請以 JavaScript 寫一段程式篩選出所有分數（score）不為 null、且大於 70 分的課程（class），需維持原本 JSON 格式：
var json = [
  {
    class: 'Chinese',
    score: 80
  },
  {
    class: 'English',
    score: 65
  },
  {
    class: 'Math',
    score: 90
  },
  {
    class: 'History',
    score: null
  }
]

公司九
PHP 面試的題目
1. 請用PHP寫出一個，可以印出 hello world 的 callback function
2. 請寫出 session、cookie、localstroage 的差異
3. 使用 SQL insert into 需要注意甚麼細節
4. MVC 與 MVVM 是甚麼東西?
5. 請說明 RESTful 是甚麼
6. $a = 11.02;
  $b = 2.01 + 9.01;
  a與b是否相同，請說明原因
7. 說明 transaction

公司十
//1 會印出什麼
var a = 'outside'
function f(){
    console.log(a);
    var a = 'inside'
}
f()

//2 會印出什麼
var m=true, n=1
console.log(m==n);
console.log(m===n);
console.log(m==n==1);
console.log(m==n===1);
console.log(m===n==1);
console.log(m==n==0);
console.log(m===n==0);

//3 會印出什麼
for(let i=0; i<5; i++){
    setTimeout(function(){
        console.log(i)},i*10000)
}

//4 會印出什麼
console.log('one');
setTimeout( function(){
    console.log('two')   
},0)
console.log('three');

//5 會印出什麼
var str1 = 'hello'
function fun(){
    var str2 = 'world'
    console.log(str1+str2);   
}
fun()
console.log(str1+str2);

//6 會印出什麼
console.log(1+'2'+'2');
console.log(1++'2'+'2');
console.log(1+-'2'+'2');
console.log('A'+'B'+2);
console.log('A'-'B'+'2');
console.log(+1+'2'+'2');

//7 
['a', 'b', 'ccc', 'abc'] 寫可以找出最長的一樣的單字的程式碼

//8
知道的網站優化的技術?

//9
websocket, long-polling, server-sent events 的比較

//10 會印出什麼
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Page Title</title>
  <script>
    var class1 = 'class1'
    var class2 = {
        num1: 'class2.num1',
        num2: function(){
          num3 = 'num3'
        }
    }
    function f(str){
      return document.write('<p>' +  str + '</p>')
    }
    f(class1)
    f(class2.num1)
    f(class2.num3)
  </script>
</head>
<body>
  
</body>
</html>

公司十一
//筆試
//1
var foo = 10
for(let bar=0, foo=2;bar<foo; bar+=5){
    foo+=2
    console.log(foo);
}
console.log(foo);

//2
var foo = 10
for(var bar=0, foo=2;bar<foo; bar+=5){
    foo+=2
    console.log(foo);
}
console.log(foo);

//3
typeof null
typeof NaN
typeof {}
typeof []
typeof +'3'
NaN === NaN
[] === []
typeof function(){}
typeof new Date()

//4
var a = [1,2,3]
var b = a
a.push(b)
console.log(b);

//5
let foo = new Set([1, {bar: 2}, 3])
console.log(foo.has({bar: 2}));

//6
在瀏覽器小於 400px 時把所有 img 標籤隱藏

//7
排序 padding, margin, border 由外至內

//8
解釋 event bubbling 及其運作

//8
解釋 event capturing 及其運作

//9
rem, em 差別

//10
vw, vh, vmin, vmax 差別

//11
redux 是什麼？

//12
redux 的優點？

//13
console.log(100);
setTimeout(function(){
    Promise.resolve().then(()=>console.log(200))
    console.log(300)},10)
console.log(400);

//14
console.log(
    [5,5,5,5,5]
    .map((v,i)=>v+i)
    .filter((v,i)=>v%2)
    .reduce(function(sum, v, i){return sum+v+i}.bind(0, 1), 0)
);

//15
console.log('hello world'.replace(/l/,'L').replace(/$$$/g),'$$$$');($$$是指一些代號)

//16
考題 array=[1,2,3,4,6,3,8,2] ，舉出兩個數字加總等於10的可能


//口頭記得的有：
1.jQuery 和 React 的差別
2.對模組化開發的解釋
3.對元件的解釋
4.對 functional programming 的感覺
5.覺得 cookie 和  localStorage 哪個好 
6.有用過除了 redux 以外的 state management library 之類的，例如 mobx, flux …
7.對 design pattern 的認識

公司十二
1. php 中， include 與 require 相異之處。
2. 試描述框架 ( framework )
3. 試描述 MVC
4. 寫出你知道的 php framework
5. 寫出你知道的 css framework （看不懂，寫了 css 預處理器）
6. 寫出你知道的 js framework
7. 寫出你知道的 樣板函式庫 （我是寫 template engine ，但它可能是在問別的 ）
8. 樣板函式庫運作原理
9. linux like 系統上，若要依據更新日期或檔名來批次刪除檔案，你會怎麼處理
10. 試規劃訂單系統所需要的資料表含 schema
11.git / git flow
12.react 是什麼東西

公司十三
筆試題目：
// 1. What't the difference between var and let ? 

// 2. What't is IIFE and why do we use it ? 

// 3. how do you write a private variable ?

// 4. what will print if you running the following code ?
for (var i = 0; i < 5; i++) {
  setTimeout( function() {
    console.log(i);
  }, 0)
}

// 4-1. please explian why ?

// 4-2. will it only print five 5 ?

// 4-3. so, how do you print 01234 ?


// 5. what will the folling code print ?
var myObject = {
  foo: "bar",
  func: function() {
    var self = this
    console.log("outer func: this.foo= " + this.foo);
    console.log("outer func: self.foo= " + self.foo);

    (function() {
      console.log("outer func: this.foo= " + this.foo);
      console.log("outer func: self.foo= " + self.foo);
    }())
  }
}

myObject.func()

// 6. what will the folling code print ?
console.log(1);
let a = new Promise(function(resolve, reject){
  console.log(2);
  resolve(3)
})

console.log(4);
a.then(function(result) {
  console.log(result);
})

console.log(5);


// 7. please write a javascript promise that can print 1 2 3


公司十四
### 有哪些是 inline-element 跟 block-level elemnet？還有他們之間的的差別？要如何將 block-level element 轉變成inline-element？ inline-element 的 padding, margin可否設定？
    
### css3 跟 HTML5 多了什麼？
​
### 要如何優化前端？
​
### 水平置中跟垂直置中有哪些辦法可以做到？
​
### ES6 新的特性有哪些？簡單敘述 promise 是什麼？
​
## JS題目:
### 請寫出下列 javascript 的輸出內容
​
1. 
    for (var i=1; i<5; i++) {
        setTimeout(function () {
            console.log(i)
        }, i * 1000)
    }
​
2. 
    function test() {
        console.log(a)
        console.log(foo())
        var a = 1
        function foo() {
            return 2
        }
    }
    test()
​
3. 
    var f = true
    if(f === true) {
        var a = 10
    }
    function fn() {
        var b = 20
        c = 30
    }
    fn()
    console.log(a, b, c)
​
4.  
    var a = [1, 2, 3]
    var b = a
    a.push(5)
    var obj = { 1: 'a', 2: b }
    console.log(b, obj[ 0 ], obj[ 2 ], obj.2)
​
5. 
    var fullname = 'John Doe'
    var obj = {
        fullname: 'Colin Ihrig',
        prop: {
            fullname: 'Aurelio De Rosa',
            getFullname: function() {
                return this.fullname
            }
        }
    }
    console.log(obj.prop.getFullname())
    var test = obj.prop.getFullname
    console.log(test())
​
6. 請用 JS 寫出能計算費波那契數列( Fibonacci )第 n 個值的函式。

公司十五
// JS 基本類型？引用類型？

// DOM 事件的流程，觸發到結束的整個過程。

// 列出 Array 常用的 method

//! 如何判斷一個 物件是一個 Array ? 至少列出兩個方法

// 簡單說明一下 this

// 以下輸出是？
const person = {
  name: 'tom',
  say: function() {
    return function () {
      console.log(this.name);
    }
  }
}

person.say()()

// 以下輸出是？
setTimeout( ()=> console.log('a'), 0)
var p = new Promise( (resolve)=> {
  console.log('b');
  resolve()
})

p.then( ()=> console.log('c').catch( (err)=> console.log('d') ))
console.log('e');

公司十六
Front-end Engineer Test
‘寫出以下程式兩個 console.log 結果是：’
var foo = "Hello";
(function() {
    var bar = " World";
    console.log(foo + bar);
})();
console.log(foo + bar);
‘請“依序”寫出 console.log 結果’
function Dog(name, legs, age) {
    setTimeout(function() {
        console.log('name: ' + name);
        console.log('legs: ' + this.legs);
        console.log('age: ' + this.age++);
    }, 0);

    this.logMyName = function() {
        console.log(this.name);
    }
}
var snoopy = new Dog('Snoopy', 4, 10);
snoopy.logMyName();
var charlie = {
    name: 'Charlie',
    logMyName: snoopy.logMyName
}
charlie.logMyName();
‘試寫出 json 資料格式’
‘請寫出以下程式 console.log 結果’
var oneadArray = ["a", "b", "c"];

oneadArray.push("b")
console.log(oneadArray)

oneadArray.pop();
console.log(oneadArray)

oneadArray.shift()
console.log(oneadArray)

oneadArray.unshift("d")
console.log(oneadArray)

var tempAry = oneadArray.slice(0, 2)
console.log(tempAry)
‘請用 forEach 列出 oneArr 所有值’
var oneArr = [1, 2, 3];
‘請用 prototype 的方式, 將 oneObj 加入一個 name 屬性，並給值為你的英文名字’
var oneObj = {};
‘寫出 console.log 的結果’
var x = 1;
var y = x;
x = 2;
console.log(y);

var a = { name: "A" };
var b = a;
b.name = "B";
console.log(a.name)
‘請寫出以下程式 console.log 結果’
var onead

if(onead === undefined) {
    console.log('true')
} else {
    console.log('false')
}

if(onead === 'undefined') {
    console.log('true')
} else {
    console.log('false')
}
‘用三元運算子的方式寫出來’
if( num === 0) {
    console.log('true')
} else {
    console.log('false')
}
‘請用 Singleton 方式實作一個 oneadObj 物件’
‘請用 Factory Pattern 方式實作一個 oneadObj 物件’

十七
JS熱門面試題
https://docs.google.com/forms/d/e/1FAIpQLSejHq3uUFMMaWOuUK6miSCB4oe3OZJLoZqByiuCLkL1tqK8CQ/viewform

公司十八
Please order CSS priority below.
1.*
2.inline style
3.ID
4.element
5.What is different between justiy-content and align-self?
6.Compare with <script>, <script defer>, <script await> and describe.
Please show the result of console.log()

console.log(a);
let a = 'a';

b = 'b';
console.log(b);

console.log(c);
var c = 'c';

console.log(d);
function d() { return 'd' };

const test1 = () => this;
console.log(test1);

const str2 = 'test2';
const test2 = function() { return this.str2 };
console.log(test2());

const str3 = 'str3';
const obj3 = {
    str3 : 'test3',
    test3 : function() { return str3 }
}
console.log(obj3.test3());
console.log(obj3.test3.call(this));

let str4 = 'str4';
function test4() {
    let str4 = 'test4';
    console.log(this.str4);
    console.log(str4);
}
test4();
What is Promise in ES6?
Please describe simply the one-way data flow in Vue.
Please implement the function that can sum with each character. Each capital letter and small letter indicates different number

// for example:
// a = 1, b = 2, c = 3...
// A = -1, B = -2, C = -3...

Result:
'TaiwanEFT'.sumChar()  // -3
'JavaScript'.sumChar() // 61

